import random

while True:
    
    print("\n")
    print("1.Rock")
    print("2.Paper")
    print("3.Scissors")
    selection = int(input("Enter your throw:"))

    if(selection == 1):
        player_throw = "Rock"
    elif(selection == 2):
        player_throw = "Paper"
    else:
        player_throw = "Scissors"
        
    print("\n")
    print("Player throws:", player_throw)

# Now computer is choosing random throw.

    throws = ["Rock", "Paper", "Scissors"]
    computer_throw = random.choice(throws)

    print("Computer throws:" ,computer_throw)

# Rock, Paper, Scissors Rules:

# Rock beats Scissors
# Scissors beats Paper
# Paper beats Rock

    if(player_throw == computer_throw):
       print("It's tie")
    elif(player_throw == "Rock"):
        if(computer_throw == "Paper"):
           print("Computer Wins.")
        elif(computer_throw == "Scissors"):
           print("Player wins.")
    elif(player_throw == "Paper"):
        if(computer_throw == "Scissors"):
           print("Computer wins.")
        elif(computer_throw == "Rock"):
           print("Player wins.")
    elif(player_throw == "Scissors"):
        if(computer_throw == "Rock"):
           print("Computer Wins.")
        elif(computer_throw == "Paper"):
           print("Player wins.")
           
    print("\n")
    print("1.Play again")
    print("2.Quit")
    selection = int(input("Enter your choice:"))

    if(selection == 2):
            break
                 
    



        
